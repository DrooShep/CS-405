
#include <iostream>
#include <exception>

// Custom exception class from std::exception
class MyCustomException : public std::exception 
{
public:
    const char* what() const noexcept override 
    {
        return "MyCustomException: Something went wrong.";
    }
};

bool do_even_more_custom_application_logic()
{

    throw std::runtime_error("An error occurred in do_even_more_custom_application_logic");

}
void do_custom_application_logic()
{

    std::cout << "Running Custom Application Logic." << std::endl;
    try 
    {
        do_even_more_custom_application_logic();
        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }

    catch (const std::exception& ex) 
    {
        std::cout << "Caught std::exception: " << ex.what() << std::endl;
    }

    // This will throw a custom exception that is derived from std::exception and catch it in main
    throw MyCustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // This will throw an exception that will deal with dividing by zero.
    if (den == 0) 
    {
        throw std::invalid_argument("Invalid argument: Division by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;
    // This try/catch block will catch the exception thrown by divide.
    try 
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }

    catch (const std::exception& ex) 
    {
        std::cout << "Caught exception in do_division(): " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try 
    {
     
        do_division();
        do_custom_application_logic();
    }
    // This exception handler will catch my custom exception.
    catch (const MyCustomException& ex) 
    {
        std::cout << "Caught MyCustomException: " << ex.what() << std::endl;
    }
    // This exception handler will catch the std::exception.
    catch (const std::exception& ex) 
    {
        std::cout << "Caught std::exception: " << ex.what() << std::endl;
    }
    // This catch all handler will catch uncaught exceptions.
    catch (...) 
    {
        std::cout << "Caught an uncaught exception." << std::endl;
    }
    
    return 0;
}

